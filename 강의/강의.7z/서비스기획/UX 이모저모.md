## Thumbzone

- 모바일 애플리케이션의 설계 시 한 손으로 기기를 파지했을 때 UI 요소에 접근하기 위한 엄지손가락의 가동 범위
- 되도록 Thumbzone 안에 자주 사용하는 기능을 배치할 것이 요구됨

![](../attachments/Pasted%20image%2020241119031428.png)

## 3-Click Rule

- 애플리케이션의 모든 기능에 접근하는 데 3번의 클릭을 넘으면 안된다.
	- 라는 주장을 했던 **2001년의 UX 미신**
- 비슷하게 최상위 메뉴가 7개 이하여야 한다라는 미신도 있다.

![](../attachments/Pasted%20image%2020241119031714.png)

## 예쁜 웹사이트는 왜 전환에 실패하는가

- [Why Beautiful Websites Don't Convert](https://www.youtube.com/watch?v=Toonu-cTE60)

![](../attachments/Pasted%20image%2020241119033614.png)

## 10 Laws of UX

[10 Laws of UX](https://brunch.co.kr/@sower/167)

- 제이콥의 법칙: 다수가 사용하는 인터페이스를 제공해라
- 피츠의 법칙: 사람들은 크고 가까운 것을 선택하는 경향이 있다.
- 힉의 법칙: 선택지가 많아지면 선택에 걸리는 시간은 (로그함수의 형태로) 늘어난다.
- 밀러의 법칙: 사람들이 한 번에 기억할 수 있는 건 7(±2)개 정도의 요소뿐이다.
- 포스텔의 법칙: 사용자의 행동(입력)은 너그럽게 수용하되, 입력을 요구하는 건 제한하라.

***

- 피크엔드 법칙: 사람들은 절정과 마지막 순간만을 기억한다.
- 심미적 사용성: 예쁘면 사람들은 사용성이 좋다고 생각한다.
- 폰 레스토프 효과: 비슷한 사물이 여러 개 있으면 그 중 색다른 것만 기억한다.
- 테슬러의 법칙: 시스템의 복잡성은 어느 한도 이상으로 축소할 수 없다.
- 도허티 임계: 사람들의 생산성을 증대시키는 인터랙션의 속도는 0.4초 이하이다.

## One thing per page

- 한 화면에는 유저가 한 번에 소화시킬 수 있는 만큼의 정보량(One thing)을 제공해야 한다.
- 토스가 좋아하는 UX 원칙
- [거꾸로 입력하는 가입 화면](https://toss.tech/article/toss-signup-process)
- [토스 디자이너들의 프로덕트 원칙](https://brunch.co.kr/@figmaster/8)

![](../attachments/Pasted%20image%2020241119035619.png)

## 넛지 이론, Nudge Theory

- 팔꿈치로 쿡쿡 찌르다. 라는 의미의 영단어로 **자유주의적 개입 또는 간섭**을 의미
- 행동을 유도하는 대표적인 방법으로 인센티브와 벌칙(당근과 채찍)이 있다면
- 넛지는 은연 중에 작은 신호들이나 의도적인 혼란으로 행동을 유도하는 방법
- 과하면 다크 패턴이 된다. 

![](../attachments/Pasted%20image%2020241119052446.png)

## 다크 패턴

- 사용자에게 손해, 그리고 서비스에 이익이 되도록 의도적으로 UX를 배치하는 것.

***

### 해리 브리그널의 12 Dark Patterns

1. 속임수 질문(Trick Questions)
2. 소매넣기(Sneak into Basket), 2014년부터 EU에서 불법
3. 싸구려 호텔(Roach Motel), 가입은 쉽게 해지는 어렵게
4. 개인정보 주커링(Privacy Zuckering)
5. 가격비교 차단(Privacy Comparison Prevention)
6. 주의집중 분산(Misdirection)
7. 숨겨진 가격(Hidden Cost)
8. 미끼와 스위치(Bait and Switch), 숨겨진 버튼
9. 호혜적 선택강요(Confirmshaming)
10. 위장된 광고(Disguised Ads), 콘텐츠로 위장한 광고
11. 강제 연속 결제(Forced Continuity), EU불법
12. 친구로 위장한 스팸(Friend Spam)

---

![](../attachments/Pasted%20image%2020241119053358.png)

---

![](../attachments/Pasted%20image%2020241119053735.png)

---

![](../attachments/uxdesign06.png)

---

### 콜린 그레이의 5 Dark Patterns

1. 잔소리형(Nagging)
2. 경로방해형(Obstruction)
3. 인터페이스 간섭(Interface Interference)
	- Checked by default
	- Next 버튼 시차
4. 은닉형(Sneaking)
5. 행동강제형(Forced Action)

---

![](../attachments/Pasted%20image%2020241119053937.png)

